package lt.v.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lt.v.Dishes;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DishService {
    private List<Dishes> dishesList=new ArrayList<>();

    public void createNeewDish() throws IOException {
        Dishes dishe1 = new Dishes("Drinks","Alus","Utenos",5.00);
        dishesList.add(dishe1);
        printAllRecords();
        saveToFileJson();
    }

    public List<Dishes> getDishesList() {
        return dishesList;
    }

    public void saveToFileJson() throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        File file = new File("Records.json");

        mapper.writeValue(file, getDishesList());
    }
    public void printAllRecords() {
        //resetNumber();
        System.out.println(String.format("x%-200sx", "x".repeat(200)));
        for (Object o : getDishesList()) {
            System.out.println(String.format("|%-200s|", ("   " + o)));

        }
    }

}
