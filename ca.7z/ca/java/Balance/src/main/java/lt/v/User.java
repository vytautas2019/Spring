package lt.v;

public class User {
    private int idUser;
    private String nameUser;
    private String password;

}
