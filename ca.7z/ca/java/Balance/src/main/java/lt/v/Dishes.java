package lt.v;

import java.util.List;

public class Dishes {
    private int idDish;
    private  String categoryDish;
    private String nameDish;
    private  String descriptionDish;
    private double priceDish;
    private  int evaluationDish;
    private String comentsDish;

    static int idSetDish = 0;
    private  int evaluation=0;


    public Dishes(String categoryDish, String nameDish, String descriptionDish, double priceDish) {
        this.categoryDish = categoryDish;
        this.nameDish = nameDish;
        this.descriptionDish = descriptionDish;
        this.priceDish = priceDish;
        this.evaluationDish = evaluation;
        String comentEmpty = "";
        this.comentsDish = comentEmpty;
    }

    public int getIdDish() {
        return idDish;
    }

    public void setIdDish(int idDish) {
        this.idDish = idDish;
    }

    public String getNameDish() {
        return nameDish;
    }

    public void setNameDish(String nameDish) {
        this.nameDish = nameDish;
    }

    public double getPriceDish() {
        return priceDish;
    }

    public void setPriceDish(double priceDish) {
        this.priceDish = priceDish;
    }

    public String getDescriptionDish() {
        return descriptionDish;
    }

    public void setDescriptionDish(String descriptionDish) {
        this.descriptionDish = descriptionDish;
    }

    public String getCategoryDish() {
        return categoryDish;
    }

    public void setCategoryDish(String categoryDish) {
        this.categoryDish = categoryDish;
    }

    public int getEvaluationDish() {
        return evaluationDish;
    }

    public void setEvaluationDish(int evaluationDish) {
        this.evaluationDish = evaluationDish;
    }

    public static int getIdSetDish() {
        return idSetDish;
    }

    public static void setIdSetDish(int idSetDish) {
        Dishes.idSetDish = idSetDish;
    }

    @Override
    public String toString() {
        return "Dishes{" +
                "idDish=" + idDish +
                ", categoryDish='" + categoryDish + '\'' +
                ", nameDish='" + nameDish + '\'' +
                ", descriptionDish='" + descriptionDish + '\'' +
                ", priceDish=" + priceDish +
                ", evaluationDish=" + evaluationDish +
                ", comentsDish='" + comentsDish + '\'' +
                '}';
    }
}
