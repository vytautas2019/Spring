package lt.v;

public enum Currency {
    EUR,USD,CAD,GBP,NOK,CHF
}
